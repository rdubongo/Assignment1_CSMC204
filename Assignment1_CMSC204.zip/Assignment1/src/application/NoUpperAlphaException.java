package application;

/**
* NoUpperAlphaExceptions thrown if the password does not contain at least one upper case letter
*/
public class NoUpperAlphaException extends Exception{
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public NoUpperAlphaException() {
		super("The password must contain at least one uppercase alphabetic character");
	}
}


