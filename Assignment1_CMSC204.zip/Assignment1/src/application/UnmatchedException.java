package application;

/**
* UnMatchedException thrown if the retyped password does not match
*/
public class UnmatchedException extends Exception{
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public UnmatchedException() {
		super("Passwords do not match");
		
	}
}

