package application;

/**
* NoSpecialCharacterException thrown if the password does not contain at least one special character
*/
public class NoSpecialCharacterException extends Exception {
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public NoSpecialCharacterException() {
		super("The password must contain at least one special character");
	}
	
}


