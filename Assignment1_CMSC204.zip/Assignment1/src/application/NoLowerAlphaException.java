package application;

/**
* NoLowerAlphaExceptions thrown if the password does not contain at least one lower case letter
*/
public class NoLowerAlphaException extends Exception{
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public NoLowerAlphaException() {
		super("The password must contain at least one lowercase alphabetic character");
	}
}


