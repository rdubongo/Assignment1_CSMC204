package application;

/**
* WeakPasswordException thrown if the password contains less than ten characters
*/
public class WeakPasswordException extends Exception {
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public WeakPasswordException(){
		super("The password is OK but weak - it contains fewer than 10 characters");
		
	}
}
