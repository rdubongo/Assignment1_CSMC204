package application;

/**
* LengthException thrown if the passwords length does not meet the 6 characters criteria
*/
public class LengthException extends Exception {
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public LengthException() {
		super("The password must be at least 6 characters long");
		
	}
	
}
