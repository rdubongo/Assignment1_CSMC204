package application;

/**
* NoDigitException thrown if the password does not contain at least one digit
*/
public class NoDigitException extends Exception {
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public NoDigitException() {
		super("The password must contain at least one digit");
	}
}

