package application;

/**
* InvalidSequenceException thrown if the password contains more than 2 of the same characters
*/
public class InvalidSequenceException extends Exception{
	
	/**
	 * default constructor
	 * calls superclass and display error message
	 */
	public InvalidSequenceException() {
		super("The password can't contain more than two of the same character in sequence");
	}
}

