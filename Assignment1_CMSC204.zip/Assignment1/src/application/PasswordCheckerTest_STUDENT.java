package application;


import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * STUDENT tests for the methods of PasswordChecker
 * @author 
 *
 */
public class PasswordCheckerTest_STUDENT {
	
	ArrayList<String> passwords;
	
	@Before
	public void setUp() throws Exception {
		String[] list = {
				"Small", "goodPassword@5", "NEEDSALOWERC@", "needsupperc!", "needsAdigit", "ValidP@s1"				
		};
		passwords = new ArrayList<String>();
		passwords.addAll(Arrays.asList(list));
	}

	@After
	public void tearDown() throws Exception {
		passwords.clear();
	
	}

	/**
	 * Test if the password is less than 6 characters long.
	 * This test should throw a LengthException for second case.
	 */
	@Test
	public void testIsValidPasswordTooShort()
	{
		try {
			assertTrue(PasswordCheckerUtility.isValidPassword("goodPassword@5"));
			PasswordCheckerUtility.isValidPassword("notVa");
			assertTrue("Exception not throw", false);
		}catch(LengthException e){
			assertTrue("LengthException thrown", true);
		}catch(Exception e){
			assertTrue("Other Exception was thrown", true);
		}
	}
	
	/**
	 * Test if the password has at least one uppercase alpha character
	 * This test should throw a NoUpperAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoUpperAlpha()
	{
		try {
			PasswordCheckerUtility.isValidPassword("needsupperc!");
			fail("Exception not throw");
		}catch(NoUpperAlphaException e){
			assertTrue("NoUpperAlphaException thrown", true);
		}catch(Exception e){
			fail("Other Exception was thrown");
		}
	}
	
	/**
	 * Test if the password has at least one lowercase alpha character
	 * This test should throw a NoLowerAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoLowerAlpha()
	{
		try {
			PasswordCheckerUtility.isValidPassword("NEEDSALOWERC@");
			fail("Exception not throw");
		}catch(NoLowerAlphaException e){
			assertTrue("NoLowerAlphaException thrown", true);
		}catch(Exception e){
			fail("Other Exception was thrown");
		}
	}
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a WeakPasswordException for second case
	 */
	@Test
	public void testIsWeakPassword()
	{
		try {
			assertTrue(PasswordCheckerUtility.isValidPassword("ValidP@ss1"));
		}catch(Exception e){
			fail("WeakPasswordException thrown");
		}
	}
	
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsValidPasswordInvalidSequence()
	{
		try {
			assertTrue(PasswordCheckerUtility.isValidPassword("ValidP@as1"));
			PasswordCheckerUtility.isValidPassword("ToMaaany@1");
			assertTrue("Exception not throw", false);
		}catch(InvalidSequenceException e){
			assertTrue("InvalidSequenceException thrown", true);
		}catch(Exception e){
			assertTrue("Other Exception was thrown", true);
		}
	}
	
	/**
	 * Test if the password has at least one digit
	 * One test should throw a NoDigitException
	 */
	@Test
	public void testIsValidPasswordNoDigit()
	{
		try {
			PasswordCheckerUtility.isValidPassword("NoDigit@");
			fail("Exception not throw");
		}catch(NoDigitException e){
			assertTrue("NoDigitException thrown", true);
		}catch(Exception e){
			fail("Other Exception was thrown");
		}
	}
	
	/**
	 * Test correct passwords
	 * This test should not throw an exception
	 */
	@Test
	public void testIsValidPasswordSuccessful()
	{
		try {
			assertTrue(PasswordCheckerUtility.isValidPassword("ValidSucessP@ss1"));
		}catch(Exception e){
			fail("WeakPasswordException thrown");
		}
	}
	
	/**
	 * Test the invalidPasswords method
	 * Check the results of the ArrayList of Strings returned by the validPasswords method
	 */
	@Test
	public void testInvalidPasswords() {
		ArrayList<String> invalidPasswords = PasswordCheckerUtility.getInvalidPasswords(passwords);
		
		assertTrue(invalidPasswords.contains("Small"));
		assertTrue(invalidPasswords.contains("NEEDSALOWERC@"));
		assertTrue(invalidPasswords.contains("needsupperc!"));
		assertTrue(invalidPasswords.contains("needsADigit"));		
	}	
}
