package application;

import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.regex.*;
/**
* 
* @author Rixa Dubon
* This passwordCheckerUtility class contain methods that validates passwords according to given criteria
* such as length, weakness, lower and upper case characters, containing a digit, containing a special character,
* checking the validity of a password and returning a list of invalid passwords. If the criteria is not met
* Exceptions are thrown.
*/
public class PasswordCheckerUtility {
	
	/**
	* This methods compares the equality of two passwords and throws exception if not 
	* @param password string to be checked\
	* @param string to be checked against password 
	* @throws Unmatchedexception if passwords are not the same 
	*/
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException{
		if(!password.equals(passwordConfirm)){ 
			throw new UnmatchedException();
			}
		}
	/**
	* This methods compares equality of both passwords 
	* @param password string to be checked 
	* @param passwordConfirm striing to be checked against
	* returns true if both passwords are the same 
	*/
	public static boolean comparePasswordsWithReturn(String password, String passwordConfirm){
	    return password.equals(passwordConfirm);
	}
	
	/**
	 * method that validated the passwords length which must be at least 6 characters long
	 * @param password string to be checked for length
	 * @return true if it meets the minimum length required
	 * @throws LengthException if the minimum required length is not met
	 */
	public static boolean isValidLength(String password) throws LengthException{
		if(password.length() < 6) {
			throw new LengthException();
		}
		
		return true;		
	}
	
	/**
	 * method to check that the passwords contains an upper case alpha character
	 * @param password the string to be checked for alpha character requirement
	 * @return true if the password contain an upper alpha character
	 * @throws NoUpperAlphaException if the password does meet upper case requirement
	 */
	public static boolean hasUpperAlpha(String password) throws NoUpperAlphaException{
		
		for(char Individualcharacter: password.toCharArray()) {
			if(Character.isUpperCase(Individualcharacter)) {
				return true;
			}
		}
		throw new NoUpperAlphaException();
	}
	
	/**
	 * method to check that the passwords contains an lower case character as per requirement
	 * @param password the string to be checked for lower case character requirement
	 * @return true if the password contain a lower case character
	 * @throws NoLowerAlphaException if the password does meet lower case requirement
	 */
	public static boolean hasLowerAlpha(String password) throws NoLowerAlphaException{
		for(char Individualcharacter: password.toCharArray()) {
			if(Character.isLowerCase(Individualcharacter)) {
				return true;
			}
		}
		throw new NoLowerAlphaException();
	}
	
	
	/**
	 * Method to check if the password contains a numeric character
	 * @param password the string to be checked for a digit
	 * @return true if the password contain a digit
	 * @throws NoDigitException is the password does not meet the requirement of containing a digit
	 */
	public static boolean hasDigit(String password) throws NoDigitException{
		
		for(char individualCharacter: password.toCharArray()){
			if(Character.isDigit(individualCharacter)) {
				return true;
			}
			
		}
		throw new NoDigitException();
	}
	
	/**
	 * Method to check if the entered password contain a special character as per required
	 * @param password string to be checked for a special character
	 * @return true if the string contains a special character
	 * @throws NoSpecialCharacterException if the password does not contain an special character
	 */
	public static boolean hasSpecialChar(String Password) throws NoSpecialCharacterException{
		Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
		Matcher matcher = pattern.matcher(Password);
		
		if(!matcher.matches()) {
			return true;
		}
		
		throw new NoSpecialCharacterException();
	}
	
	/**
	 *  This method checks that there no more than 2 of the same characters in sequence
	 * @param password String to be checked for more than 2 characters
	 * @returns true if the password does not contain more than two characters in sequence
	 * @throws InvalidSequenceExceptions if more than 2 of the same characters are found in the sequence
	 */
	public static boolean NoSameCharInSequence(String password) throws InvalidSequenceException {
	    int count = 1;
	    for (int i = 1; i < password.length(); i++){
	        if (password.charAt(i) == password.charAt(i - 1)) {
	            count++;
	            if (count > 2){
	                throw new InvalidSequenceException();
	            }
	        } else {
	            count = 1;
	        }
	    }
	    return true;
	}
	/**
	 *  Method to check the validity of one password according all the rules established
	 *  @param password which is the string to be checked for validity
	 *  @returns true if the password is valid
	 *  @throws LengthException
	 *  @throws NoUpperAlphaException
	 *  @throws NoLowerAlphaException
	 *  @throws NoDigitException
	 *  @throws NoSpecialCharacterException
	 *  @throws InvalidSequenceException
	 */	
	public static boolean isValidPassword(String password) throws LengthException, NoUpperAlphaException,
	NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException{
		  
		boolean valid = true;

	    try {
	        isValidLength(password);
	    }catch(LengthException e){
	        valid = false;
	        throw e; 
	    }

	    try {
	        hasUpperAlpha(password);
	    }catch(NoUpperAlphaException e){
	        valid = false;
	        throw e;
	    }

	    try{
	        hasLowerAlpha(password);
	    }catch(NoLowerAlphaException e){
	        valid = false;
	        throw e;
	    }

	    try{
	        hasDigit(password);
	    }catch(NoDigitException e){
	        valid = false;
	        throw e; 
	    }

	    try{
	        hasSpecialChar(password);
	    }catch(NoSpecialCharacterException e){
	        valid = false;
	        throw e; 
	    }

	    try{
	        NoSameCharInSequence(password);
	    }catch(InvalidSequenceException e){
	        valid = false;
	        throw e;
	    }
	    return valid;
	}
	
	/**
	 * Method to check if the passwords contains more than 6 character and less than 9 for a strong password
	 * while also checking for the validity beforehand
	 * @param password string to be checked for a total of 6-9 characters
	 * @return true if the password has between 6 and 9 characters
	 * @throws isWeakPassword if the passwords has over 9 character or less than 6.
	 */
	public static boolean isWeakPassword(String password) throws WeakPasswordException, LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException{
		if(isValidPassword(password)){
			if(password.length() >= 6 && password.length() <=9){
				throw new WeakPasswordException();
				
			}
			return false;
		}
		return true;
		
	}
	/**
	 * This method checks a list of passwords and identifies the invalid ones based on validation criteria
	 * however, weak passwords are not considered invalid
	 * @param passwords list of passwords 
	 * @return an ArrayList of invalidPasswords with their message  
	 * 
	 */
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
		ArrayList<String> invalidPasswords = new ArrayList<>();
  
		for (String currentPassword : passwords) {
			try {
				PasswordCheckerUtility.isValidPassword(currentPassword);
			} catch (LengthException | NoUpperAlphaException | NoLowerAlphaException |
					NoDigitException | NoSpecialCharacterException | InvalidSequenceException e) {
				invalidPasswords.add(currentPassword + " " + e.getMessage());
			}
		}
		return invalidPasswords;
	}
	
}


